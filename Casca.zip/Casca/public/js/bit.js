document.addEventListener('DOMContentLoaded', () => {
    const tabla = document.getElementById('vehiculosTabla'); // Asegúrate de que exista una tabla con este ID en tu HTML.

    // Función para cargar datos desde el servidor
    async function cargarVehiculos() {
        try {
            const response = await fetch('/scr_tabla?tipo=cliente'); // Asegúrate de que el tipo sea 'cliente'
            if (!response.ok) {
                throw new Error('Error al obtener los vehículos.');
            }
            const vehiculos = await response.json();

            console.log(vehiculos); // Verifica los datos antes de procesarlos

            // Limpiar la tabla antes de añadir datos
            tabla.innerHTML = `
                <thead>
                    <tr>
                        <th>ID Vehículo</th>
                        <th>Correo</th>
                        <th>Placa</th>
                    </tr>
                </thead>
                <tbody></tbody>
            `;

            const tbody = tabla.querySelector('tbody');

            // Poblar la tabla con los datos recibidos
            vehiculos.forEach((vehiculo) => {
                const fila = document.createElement('tr');
                fila.innerHTML = `
                    <td>${vehiculo.id_vehiculo}</td>
                    <td>${vehiculo.correo}</td>
                    <td>${vehiculo.placa}</td>
                `;
                tbody.appendChild(fila);
            });
        } catch (error) {
            console.error('Error al cargar los vehículos:', error);
            alert('Hubo un error al cargar los vehículos.');
        }
    }

    // Cargar los vehículos al cargar la página
    cargarVehiculos();
});
